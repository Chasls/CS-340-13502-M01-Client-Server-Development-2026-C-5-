"""Grazioso Salvare rescue candidate dashboard for CS 340 Project Two."""
import base64
import math
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import dash_leaflet as dl
from dash import html, dcc, dash_table
from dash.dependencies import Input, Output
from jupyter_dash import JupyterDash
from CRUD_Python_Module import AnimalShelter

# Model: all collection access uses the reusable Project One CRUD module.
shelter = AnimalShelter("aacuser", "AAC-Grazioso-2026#")
FILTERS = {
    "water": (["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"], "Intact Female", 26, 156),
    "mountain": (["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"], "Intact Male", 26, 156),
    "disaster": (["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"], "Intact Male", 20, 300),
}


def rescue_query(rescue_type):
    """Return the specification's breed, sex, and inclusive age criteria."""
    if rescue_type not in FILTERS:
        return {}
    breeds, sex, minimum, maximum = FILTERS[rescue_type]
    # Preferred breeds also include their shelter-recorded Mix variants.
    variants = sorted(set(breeds + [b + " Mix" for b in breeds if not b.endswith(" Mix")]))
    return {"animal_type": "Dog", "breed": {"$in": variants},
            "sex_upon_outcome": sex,
            "age_upon_outcome_in_weeks": {"$gte": minimum, "$lte": maximum}}


def retrieve(rescue_type):
    """Remove BSON IDs and normalize missing values for browser serialization."""
    frame = pd.DataFrame(shelter.read(rescue_query(rescue_type)))
    frame = frame.drop(columns=["_id"], errors="ignore")
    return frame.astype(object).where(pd.notnull(frame), None).to_dict("records")


initial_records = retrieve("reset")
if not initial_records:
    raise RuntimeError("The AAC collection is empty or unavailable. Check MongoDB before starting.")
fields = ["animal_id", "name", "animal_type", "breed", "sex_upon_outcome",
          "age_upon_outcome_in_weeks", "outcome_type", "location_lat", "location_long"]
logo_path = Path("Grazioso Salvare Logo.png")
if not logo_path.exists():
    logo_path = Path("code_files") / logo_path
logo = base64.b64encode(logo_path.read_bytes()).decode("ascii")
app = JupyterDash(__name__)

# View: compact layout keeps the brand, identifier, controls, table, and charts together.
app.layout = html.Div([
    html.Div([
        html.Img(src="data:image/png;base64," + logo, alt="Grazioso Salvare logo",
                 style={"height": "92px", "width": "130px", "objectFit": "contain"}),
        html.Div([html.H1("Grazioso Salvare", style={"margin": "0", "fontSize": "28px"}),
                  html.P("Search and rescue candidate dashboard", style={"margin": "5px 0"}),
                  html.Strong("Chas Steves | cstevens | CS 340 Project Two")]),
    ], style={"display": "flex", "gap": "22px", "alignItems": "center"}),
    html.Hr(),
    html.Label("Choose a rescue profile", style={"fontWeight": "bold"}),
    dcc.RadioItems(id="filter-type", options=[
        {"label": "Reset / All Animals", "value": "reset"},
        {"label": "Water Rescue", "value": "water"},
        {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
        {"label": "Disaster or Individual Tracking", "value": "disaster"}],
        value="reset", inline=True, labelStyle={"marginRight": "20px"},
        style={"padding": "12px 0"}),
    html.Div(id="result-count", style={"fontWeight": "bold", "marginBottom": "8px"}),
    html.P("Sort column headings or type a column filter. Select a row to update the location map.",
           style={"fontSize": "12px", "margin": "5px 0"}),
    dash_table.DataTable(id="datatable-id", data=initial_records,
        columns=[{"name": f.replace("_", " ").title(), "id": f} for f in fields],
        page_size=6, page_action="native", sort_action="native", sort_mode="multi",
        filter_action="native", row_selectable="single", selected_rows=[0],
        style_table={"overflowX": "auto"},
        style_cell={"fontFamily": "Arial", "fontSize": "12px", "padding": "7px",
                    "textAlign": "left", "maxWidth": "240px", "overflow": "hidden", "textOverflow": "ellipsis"},
        style_header={"backgroundColor": "#16324f", "color": "white", "fontWeight": "bold"},
        style_data_conditional=[{"if": {"state": "selected"}, "backgroundColor": "#d2f3ff"}]),
    html.Div([
        html.Div(dcc.Graph(id="breed-chart", config={"displayModeBar": False}), style={"width": "50%"}),
        html.Div(id="map-id", style={"width": "50%", "paddingTop": "10px"}),
    ], style={"display": "flex", "gap": "18px"}),
], style={"fontFamily": "Arial, sans-serif", "padding": "12px 20px", "maxWidth": "1400px", "margin": "auto", "color": "#16324f"})


# Controller: profile changes query MongoDB and clear stale table selections and filters.
@app.callback([Output("datatable-id", "data"), Output("datatable-id", "selected_rows"),
               Output("datatable-id", "page_current"), Output("datatable-id", "filter_query"),
               Output("datatable-id", "sort_by"), Output("result-count", "children")],
              Input("filter-type", "value"))
def update_dashboard(rescue_type):
    rows = retrieve(rescue_type)
    return rows, ([0] if rows else []), 0, "", [], f"{len(rows):,} animals match this profile"


@app.callback(Output("breed-chart", "figure"), Input("datatable-id", "derived_virtual_data"))
def update_chart(view_data):
    """Chart the complete filtered table, including rows beyond the current page."""
    rows = initial_records if view_data is None else view_data
    if not rows:
        figure = go.Figure()
        figure.add_annotation(text="No animals match the current filters", showarrow=False)
    else:
        counts = pd.Series([r.get("breed") or "Unknown" for r in rows]).value_counts()
        top = counts.head(8)
        if len(counts) > 8:
            top.loc["Other breeds"] = counts.iloc[8:].sum()
        figure = px.pie(names=top.index, values=top.values, hole=0.35,
                         title="Breed distribution of filtered animals")
        figure.update_traces(textinfo="percent", hovertemplate="%{label}: %{value} animals<extra></extra>")
    figure.update_layout(height=335, margin=dict(l=10, r=10, t=45, b=15),
                         font=dict(size=11), paper_bgcolor="white")
    return figure


@app.callback(Output("map-id", "children"),
              [Input("datatable-id", "derived_virtual_data"),
               Input("datatable-id", "derived_virtual_selected_rows")])
def update_map(view_data, selected_rows):
    """Use named coordinate fields and derived indices after table sorting/filtering."""
    rows = initial_records if view_data is None else view_data
    if not rows:
        return html.P("No animals match the current filters.")
    index = selected_rows[0] if selected_rows else 0
    index = index if 0 <= index < len(rows) else 0
    animal = rows[index]
    try:
        lat, lon = float(animal["location_lat"]), float(animal["location_long"])
        if not (math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("Invalid coordinates")
    except (KeyError, TypeError, ValueError):
        return html.P("The selected animal has no valid location coordinates.")
    name, breed = animal.get("name") or "Unnamed animal", animal.get("breed") or "Unknown breed"
    return [html.Strong(f"Selected animal: {name} | {animal.get('animal_id', '')}"),
            html.P(breed, style={"fontSize": "12px", "margin": "4px 0"}),
            dl.Map(center=[lat, lon], zoom=10, style={"width": "100%", "height": "275px"}, children=[
                dl.TileLayer(), dl.Marker(position=[lat, lon], children=[
                    dl.Tooltip(breed), dl.Popup([html.H3(name), html.P(breed),
                                               html.P(animal.get("animal_id", ""))])])])]


if __name__ == "__main__":
    app.run_server(mode="external", host="0.0.0.0", port=8052, debug=False)
