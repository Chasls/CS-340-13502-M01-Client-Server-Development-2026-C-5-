"""Reusable CRUD operations for the Grazioso Salvare animal database."""

from urllib.parse import quote_plus

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """Provide create, read, update, and delete access to MongoDB."""

    def __init__(
        self,
        username,
        password,
        host="localhost",
        port=27017,
        database="aac",
        collection="animals",
    ):
        """Connect to the requested MongoDB database and collection."""
        safe_username = quote_plus(username)
        safe_password = quote_plus(password)
        connection_uri = (
            f"mongodb://{safe_username}:{safe_password}@{host}:{port}/"
            f"{database}?authSource=admin"
        )

        self.client = MongoClient(connection_uri, serverSelectionTimeoutMS=5000)
        self.database = self.client[database]
        self.collection = self.database[collection]

        # Fail fast if the credentials or MongoDB service are unavailable.
        self.client.admin.command("ping")

    def create(self, data):
        """Insert one document and return True when the insert succeeds."""
        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as error:
            print(f"Create operation failed: {error}")
            return False

    def read(self, query):
        """Return all documents matching query as a list."""
        if not isinstance(query, dict):
            return []

        try:
            return list(self.collection.find(query))
        except PyMongoError as error:
            print(f"Read operation failed: {error}")
            return []

    def update(self, query, update_data):
        """Update all matching documents and return the modified count."""
        if not isinstance(query, dict) or not isinstance(update_data, dict):
            return 0
        if not update_data:
            return 0

        try:
            result = self.collection.update_many(query, update_data)
            return result.modified_count
        except (PyMongoError, ValueError) as error:
            print(f"Update operation failed: {error}")
            return 0

    def delete(self, query):
        """Delete all matching documents and return the deleted count."""
        if not isinstance(query, dict) or not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as error:
            print(f"Delete operation failed: {error}")
            return 0

    def close(self):
        """Close the MongoDB client connection."""
        self.client.close()
